function signin() {
    var email = $("#email");
    var password = $("#password");
  
    if (isNotEmpty(email) && isNotEmpty(password)) {
      $.ajax({
        url: "db/login.php",
        method: "POST",
        dataType: "text",
        data: {
          key: "login",
          email: email.val(),
          password: password.val()
        },
        success: function(response) {
          data = JSON.parse(response);
          if (data.status == 0) {
            alert(data.msg);
          } else {
            document.location = "index.php";
          }
        }
      });
    }
  }

  function isNotEmpty(inpfield) {
    //for phone
    if (inpfield.val() == "") {
      inpfield.css("border", "2px solid red");
      return false;
    } else inpfield.css("border", "");
    return true;
  }